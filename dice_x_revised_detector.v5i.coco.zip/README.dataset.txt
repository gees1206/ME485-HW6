# dice_x_revised_detector > 2024-03-31 6:52pm
https://universe.roboflow.com/ender/dice_x_revised_detector

Provided by a Roboflow user
License: CC BY 4.0

