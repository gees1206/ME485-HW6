# Dice reader > 2024-02-05 1:54pm
https://universe.roboflow.com/nitid-kayanon/dice-reader-y9new

Provided by a Roboflow user
License: CC BY 4.0

